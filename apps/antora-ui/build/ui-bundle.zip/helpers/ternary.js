'use strict'

module.exports = (condition, yes, no) => {
  return condition ? yes : no
}
