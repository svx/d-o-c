'use strict'

module.exports = (data) => {
  return JSON.stringify(data, null, 2)
}
